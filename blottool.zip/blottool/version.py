"""
Version information for blottool.
Keep this in sync with pyproject.toml.
"""

__version__ = "0.1.0"
