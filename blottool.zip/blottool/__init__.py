"""
blottool: simple, scriptable western blot densitometry.
"""

from .version import __version__  # noqa: F401
